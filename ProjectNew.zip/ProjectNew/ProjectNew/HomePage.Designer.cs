﻿namespace ProjectNew
{
    partial class frmHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHomePage));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLblJs = new System.Windows.Forms.LinkLabel();
            this.btnJsLogin = new System.Windows.Forms.Button();
            this.txtJsPassword = new System.Windows.Forms.TextBox();
            this.txtJsUserName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lin = new System.Windows.Forms.LinkLabel();
            this.btnELogin = new System.Windows.Forms.Button();
            this.txtEPassword = new System.Windows.Forms.TextBox();
            this.txtEUserName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.picBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1159, 85);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.linkLblJs);
            this.panel1.Controls.Add(this.btnJsLogin);
            this.panel1.Controls.Add(this.txtJsPassword);
            this.panel1.Controls.Add(this.txtJsUserName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(950, 140);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(318, 313);
            this.panel1.TabIndex = 1;
            this.panel1.Tag = "";
            // 
            // linkLblJs
            // 
            this.linkLblJs.AutoSize = true;
            this.linkLblJs.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLblJs.Location = new System.Drawing.Point(128, 277);
            this.linkLblJs.Name = "linkLblJs";
            this.linkLblJs.Size = new System.Drawing.Size(71, 21);
            this.linkLblJs.TabIndex = 6;
            this.linkLblJs.TabStop = true;
            this.linkLblJs.Text = "Register";
            // 
            // btnJsLogin
            // 
            this.btnJsLogin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJsLogin.Location = new System.Drawing.Point(132, 229);
            this.btnJsLogin.Name = "btnJsLogin";
            this.btnJsLogin.Size = new System.Drawing.Size(67, 30);
            this.btnJsLogin.TabIndex = 5;
            this.btnJsLogin.Text = "Login";
            this.btnJsLogin.UseVisualStyleBackColor = true;
            this.btnJsLogin.Click += new System.EventHandler(this.btnJsLogin_Click);
            // 
            // txtJsPassword
            // 
            this.txtJsPassword.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsPassword.Location = new System.Drawing.Point(118, 152);
            this.txtJsPassword.Name = "txtJsPassword";
            this.txtJsPassword.PasswordChar = '*';
            this.txtJsPassword.Size = new System.Drawing.Size(179, 29);
            this.txtJsPassword.TabIndex = 4;
            // 
            // txtJsUserName
            // 
            this.txtJsUserName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsUserName.Location = new System.Drawing.Point(118, 92);
            this.txtJsUserName.Name = "txtJsUserName";
            this.txtJsUserName.Size = new System.Drawing.Size(179, 29);
            this.txtJsUserName.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "User Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(81, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "  JobSeeker Login  ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lin);
            this.panel2.Controls.Add(this.btnELogin);
            this.panel2.Controls.Add(this.txtEPassword);
            this.panel2.Controls.Add(this.txtEUserName);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(950, 483);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(318, 313);
            this.panel2.TabIndex = 2;
            this.panel2.Tag = "";
            // 
            // lin
            // 
            this.lin.AutoSize = true;
            this.lin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lin.Location = new System.Drawing.Point(128, 277);
            this.lin.Name = "lin";
            this.lin.Size = new System.Drawing.Size(71, 21);
            this.lin.TabIndex = 6;
            this.lin.TabStop = true;
            this.lin.Text = "Register";
            // 
            // btnELogin
            // 
            this.btnELogin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnELogin.Location = new System.Drawing.Point(132, 229);
            this.btnELogin.Name = "btnELogin";
            this.btnELogin.Size = new System.Drawing.Size(67, 30);
            this.btnELogin.TabIndex = 5;
            this.btnELogin.Text = "Login";
            this.btnELogin.UseVisualStyleBackColor = true;
            this.btnELogin.Click += new System.EventHandler(this.btnELogin_Click);
            // 
            // txtEPassword
            // 
            this.txtEPassword.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEPassword.Location = new System.Drawing.Point(118, 152);
            this.txtEPassword.Name = "txtEPassword";
            this.txtEPassword.PasswordChar = '*';
            this.txtEPassword.Size = new System.Drawing.Size(179, 29);
            this.txtEPassword.TabIndex = 4;
            // 
            // txtEUserName
            // 
            this.txtEUserName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEUserName.Location = new System.Drawing.Point(118, 92);
            this.txtEUserName.Name = "txtEUserName";
            this.txtEUserName.Size = new System.Drawing.Size(179, 29);
            this.txtEUserName.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 21);
            this.label4.TabIndex = 2;
            this.label4.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 21);
            this.label5.TabIndex = 1;
            this.label5.Text = "User Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(81, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "  Employer Login  ";
            // 
            // picBox1
            // 
            this.picBox1.BackColor = System.Drawing.Color.Transparent;
            this.picBox1.Image = ((System.Drawing.Image)(resources.GetObject("picBox1.Image")));
            this.picBox1.Location = new System.Drawing.Point(25, 196);
            this.picBox1.Name = "picBox1";
            this.picBox1.Size = new System.Drawing.Size(900, 600);
            this.picBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBox1.TabIndex = 3;
            this.picBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // frmHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 825);
            this.Controls.Add(this.picBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmHomePage";
            this.Text = "HomePage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmHomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkLblJs;
        private System.Windows.Forms.Button btnJsLogin;
        private System.Windows.Forms.TextBox txtJsPassword;
        private System.Windows.Forms.TextBox txtJsUserName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel lin;
        private System.Windows.Forms.Button btnELogin;
        private System.Windows.Forms.TextBox txtEPassword;
        private System.Windows.Forms.TextBox txtEUserName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox picBox1;
        private System.Windows.Forms.Timer timer1;
    }
}

