﻿namespace ProjectNew
{
    partial class JobSeekerReg2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JobSeekerReg2));
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbJsQualification = new System.Windows.Forms.ComboBox();
            this.txtJsPassYr = new System.Windows.Forms.TextBox();
            this.btnJsReg2 = new System.Windows.Forms.Button();
            this.txtJsPercentage = new System.Windows.Forms.TextBox();
            this.txtJsBranch = new System.Windows.Forms.TextBox();
            this.txtJsUniName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(447, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 25);
            this.label1.TabIndex = 25;
            this.label1.Text = "Highest Qualification Details";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(352, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 24);
            this.label4.TabIndex = 26;
            this.label4.Text = " Highest Qualification";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(352, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 24);
            this.label6.TabIndex = 27;
            this.label6.Text = "Branch";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(352, 302);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 24);
            this.label2.TabIndex = 28;
            this.label2.Text = "Percentage";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(352, 436);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 24);
            this.label3.TabIndex = 29;
            this.label3.Text = "University Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(352, 359);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 24);
            this.label5.TabIndex = 30;
            this.label5.Text = "Passing Year";
            // 
            // cmbJsQualification
            // 
            this.cmbJsQualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbJsQualification.FormattingEnabled = true;
            this.cmbJsQualification.Items.AddRange(new object[] {
            "B.E ",
            "B.Tech",
            "M.E.",
            "M.Tech",
            "B.Sc",
            "M.Sc",
            "MCA",
            "BCA"});
            this.cmbJsQualification.Location = new System.Drawing.Point(595, 173);
            this.cmbJsQualification.Name = "cmbJsQualification";
            this.cmbJsQualification.Size = new System.Drawing.Size(177, 28);
            this.cmbJsQualification.TabIndex = 31;
            // 
            // txtJsPassYr
            // 
            this.txtJsPassYr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsPassYr.Location = new System.Drawing.Point(595, 357);
            this.txtJsPassYr.Name = "txtJsPassYr";
            this.txtJsPassYr.Size = new System.Drawing.Size(177, 26);
            this.txtJsPassYr.TabIndex = 33;
            // 
            // btnJsReg2
            // 
            this.btnJsReg2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJsReg2.Location = new System.Drawing.Point(510, 544);
            this.btnJsReg2.Name = "btnJsReg2";
            this.btnJsReg2.Size = new System.Drawing.Size(83, 34);
            this.btnJsReg2.TabIndex = 35;
            this.btnJsReg2.Text = "Next";
            this.btnJsReg2.UseVisualStyleBackColor = true;
            this.btnJsReg2.Click += new System.EventHandler(this.btnJsReg2_Click);
            // 
            // txtJsPercentage
            // 
            this.txtJsPercentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsPercentage.Location = new System.Drawing.Point(595, 300);
            this.txtJsPercentage.Name = "txtJsPercentage";
            this.txtJsPercentage.Size = new System.Drawing.Size(177, 26);
            this.txtJsPercentage.TabIndex = 36;
            // 
            // txtJsBranch
            // 
            this.txtJsBranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsBranch.Location = new System.Drawing.Point(595, 235);
            this.txtJsBranch.Name = "txtJsBranch";
            this.txtJsBranch.Size = new System.Drawing.Size(177, 26);
            this.txtJsBranch.TabIndex = 37;
            // 
            // txtJsUniName
            // 
            this.txtJsUniName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsUniName.Location = new System.Drawing.Point(595, 436);
            this.txtJsUniName.Name = "txtJsUniName";
            this.txtJsUniName.Size = new System.Drawing.Size(177, 26);
            this.txtJsUniName.TabIndex = 38;
            // 
            // JobSeekerReg2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 762);
            this.Controls.Add(this.txtJsUniName);
            this.Controls.Add(this.txtJsBranch);
            this.Controls.Add(this.txtJsPercentage);
            this.Controls.Add(this.btnJsReg2);
            this.Controls.Add(this.txtJsPassYr);
            this.Controls.Add(this.cmbJsQualification);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Name = "JobSeekerReg2";
            this.Text = "JobSeekerReg2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbJsQualification;
        private System.Windows.Forms.TextBox txtJsPassYr;
        private System.Windows.Forms.Button btnJsReg2;
        private System.Windows.Forms.TextBox txtJsPercentage;
        private System.Windows.Forms.TextBox txtJsBranch;
        private System.Windows.Forms.TextBox txtJsUniName;
    }
}