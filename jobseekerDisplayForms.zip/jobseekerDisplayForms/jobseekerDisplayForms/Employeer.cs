﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jobseekerDisplayForms
{
    public partial class EmployeerForm : Form
    {
        public EmployeerForm()
        {
            InitializeComponent();
        }

        private void lblPostNewJobs_Click(object sender, EventArgs e)
        {
           
           

        }

        private void LinklblPostNewJob_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void EmployeePanel_Paint(object sender, PaintEventArgs e)
        {
           

        }

        private void Employeer_Load(object sender, EventArgs e)
        {
            EmployeePanel.Visible = true;
            panel1.Visible = false;
            lblPostNewJobs.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            
            
            

            
            
        }
    }
}
