﻿namespace jobseekerDisplayForms
{
    partial class EmployeerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.EmployeePanel = new System.Windows.Forms.Panel();
            this.LinklblPostNewJob = new System.Windows.Forms.LinkLabel();
            this.LinklblPostedJobs = new System.Windows.Forms.LinkLabel();
            this.LinklblJobAppliedByJS = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblPostNewJobs = new System.Windows.Forms.Label();
            this.lblPostedJobs = new System.Windows.Forms.Label();
            this.lblJobAppliedByJS = new System.Windows.Forms.Label();
            this.btnPostNewJobsClose = new System.Windows.Forms.Button();
            this.btnClosePostedJobs = new System.Windows.Forms.Button();
            this.btnCloseJobAppliedByJS = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.EmployeePanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1186, 83);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // EmployeePanel
            // 
            this.EmployeePanel.Controls.Add(this.LinklblJobAppliedByJS);
            this.EmployeePanel.Controls.Add(this.LinklblPostedJobs);
            this.EmployeePanel.Controls.Add(this.LinklblPostNewJob);
            this.EmployeePanel.Location = new System.Drawing.Point(-1, 99);
            this.EmployeePanel.Name = "EmployeePanel";
            this.EmployeePanel.Size = new System.Drawing.Size(254, 465);
            this.EmployeePanel.TabIndex = 1;
            this.EmployeePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.EmployeePanel_Paint);
            // 
            // LinklblPostNewJob
            // 
            this.LinklblPostNewJob.AutoSize = true;
            this.LinklblPostNewJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinklblPostNewJob.Location = new System.Drawing.Point(13, 54);
            this.LinklblPostNewJob.Name = "LinklblPostNewJob";
            this.LinklblPostNewJob.Size = new System.Drawing.Size(111, 16);
            this.LinklblPostNewJob.TabIndex = 0;
            this.LinklblPostNewJob.TabStop = true;
            this.LinklblPostNewJob.Text = "Post New Jobs";
            this.LinklblPostNewJob.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinklblPostNewJob_LinkClicked);
            // 
            // LinklblPostedJobs
            // 
            this.LinklblPostedJobs.AutoSize = true;
            this.LinklblPostedJobs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinklblPostedJobs.Location = new System.Drawing.Point(13, 131);
            this.LinklblPostedJobs.Name = "LinklblPostedJobs";
            this.LinklblPostedJobs.Size = new System.Drawing.Size(95, 16);
            this.LinklblPostedJobs.TabIndex = 1;
            this.LinklblPostedJobs.TabStop = true;
            this.LinklblPostedJobs.Text = "Posted Jobs";
            // 
            // LinklblJobAppliedByJS
            // 
            this.LinklblJobAppliedByJS.AutoSize = true;
            this.LinklblJobAppliedByJS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LinklblJobAppliedByJS.Location = new System.Drawing.Point(13, 211);
            this.LinklblJobAppliedByJS.Name = "LinklblJobAppliedByJS";
            this.LinklblJobAppliedByJS.Size = new System.Drawing.Size(194, 16);
            this.LinklblJobAppliedByJS.TabIndex = 2;
            this.LinklblJobAppliedByJS.TabStop = true;
            this.LinklblJobAppliedByJS.Text = "Job Applied By JobSeeker";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnPostNewJobsClose);
            this.panel1.Controls.Add(this.lblPostNewJobs);
            this.panel1.Location = new System.Drawing.Point(326, 99);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 100);
            this.panel1.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnClosePostedJobs);
            this.panel2.Controls.Add(this.lblPostedJobs);
            this.panel2.Location = new System.Drawing.Point(326, 251);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 100);
            this.panel2.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnCloseJobAppliedByJS);
            this.panel3.Controls.Add(this.lblJobAppliedByJS);
            this.panel3.Location = new System.Drawing.Point(326, 410);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 100);
            this.panel3.TabIndex = 8;
            // 
            // lblPostNewJobs
            // 
            this.lblPostNewJobs.AutoSize = true;
            this.lblPostNewJobs.Location = new System.Drawing.Point(90, 15);
            this.lblPostNewJobs.Name = "lblPostNewJobs";
            this.lblPostNewJobs.Size = new System.Drawing.Size(78, 13);
            this.lblPostNewJobs.TabIndex = 0;
            this.lblPostNewJobs.Text = "Post New Jobs";
            // 
            // lblPostedJobs
            // 
            this.lblPostedJobs.AutoSize = true;
            this.lblPostedJobs.Location = new System.Drawing.Point(93, 17);
            this.lblPostedJobs.Name = "lblPostedJobs";
            this.lblPostedJobs.Size = new System.Drawing.Size(65, 13);
            this.lblPostedJobs.TabIndex = 0;
            this.lblPostedJobs.Text = "Posted Jobs";
            // 
            // lblJobAppliedByJS
            // 
            this.lblJobAppliedByJS.AutoSize = true;
            this.lblJobAppliedByJS.Location = new System.Drawing.Point(47, 13);
            this.lblJobAppliedByJS.Name = "lblJobAppliedByJS";
            this.lblJobAppliedByJS.Size = new System.Drawing.Size(136, 13);
            this.lblJobAppliedByJS.TabIndex = 0;
            this.lblJobAppliedByJS.Text = "Job Applied By JobSeekers";
            // 
            // btnPostNewJobsClose
            // 
            this.btnPostNewJobsClose.Location = new System.Drawing.Point(70, 74);
            this.btnPostNewJobsClose.Name = "btnPostNewJobsClose";
            this.btnPostNewJobsClose.Size = new System.Drawing.Size(75, 23);
            this.btnPostNewJobsClose.TabIndex = 1;
            this.btnPostNewJobsClose.Text = "Close";
            this.btnPostNewJobsClose.UseVisualStyleBackColor = true;
            this.btnPostNewJobsClose.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnClosePostedJobs
            // 
            this.btnClosePostedJobs.Location = new System.Drawing.Point(70, 74);
            this.btnClosePostedJobs.Name = "btnClosePostedJobs";
            this.btnClosePostedJobs.Size = new System.Drawing.Size(75, 23);
            this.btnClosePostedJobs.TabIndex = 2;
            this.btnClosePostedJobs.Text = "Close";
            this.btnClosePostedJobs.UseVisualStyleBackColor = true;
            // 
            // btnCloseJobAppliedByJS
            // 
            this.btnCloseJobAppliedByJS.Location = new System.Drawing.Point(70, 74);
            this.btnCloseJobAppliedByJS.Name = "btnCloseJobAppliedByJS";
            this.btnCloseJobAppliedByJS.Size = new System.Drawing.Size(75, 23);
            this.btnCloseJobAppliedByJS.TabIndex = 2;
            this.btnCloseJobAppliedByJS.Text = "Close";
            this.btnCloseJobAppliedByJS.UseVisualStyleBackColor = true;
            // 
            // EmployeerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 762);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.EmployeePanel);
            this.Controls.Add(this.pictureBox1);
            this.Name = "EmployeerForm";
            this.Text = "Employeer";
            this.Load += new System.EventHandler(this.Employeer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.EmployeePanel.ResumeLayout(false);
            this.EmployeePanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel EmployeePanel;
        private System.Windows.Forms.LinkLabel LinklblJobAppliedByJS;
        private System.Windows.Forms.LinkLabel LinklblPostedJobs;
        private System.Windows.Forms.LinkLabel LinklblPostNewJob;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnPostNewJobsClose;
        private System.Windows.Forms.Label lblPostNewJobs;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnClosePostedJobs;
        private System.Windows.Forms.Label lblPostedJobs;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnCloseJobAppliedByJS;
        private System.Windows.Forms.Label lblJobAppliedByJS;
    }
}